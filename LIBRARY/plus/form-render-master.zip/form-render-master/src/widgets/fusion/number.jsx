/**
 * Updated by Tw93 on 2019-12-07.
 * 数字输入组件
 */

import { NumberPicker } from '@alifd/next';
import numberHoc from '../../components/numberHoc';

export default numberHoc(NumberPicker);
