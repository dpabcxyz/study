/**
 * Updated by Tw93 on 2019-12-07.
 * 多选组件
 */

import { Select } from '@alifd/next';
import multiSelectHoc from '../../components/multiSelectHoc';

export default multiSelectHoc(Select);
