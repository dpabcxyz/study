/**
 * Updated by Tw93 on 2019-12-07.
 * 选择组件
 */

import { Select } from '@alifd/next';
import selectHoc from '../../components/selectHoc';

export default selectHoc(Select);
