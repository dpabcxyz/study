import map from '../../components/map';
export default map;
