/**
 * Updated by Tw93 on 2019-12-07.
 * 滑动组件
 */

import { InputNumber, Slider } from 'antd';
import sliderHoc from '../../components/sliderHoc';

export default sliderHoc(Slider, InputNumber);
