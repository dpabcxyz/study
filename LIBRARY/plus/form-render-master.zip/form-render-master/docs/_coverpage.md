<img src="https://img.alicdn.com/tfs/TB17UtINiLaK1RjSZFxXXamPFXa-606-643.png" width="146px">

# <span style="font-weight:400;">FormRender</span>

> <span style="line-height:1.8rem;font-weight:400;font-size:1.3rem">通过 JSON Schema 生成标准 Form，常用于自定义搭建配置界面生成<span>

[Playground](https://alibaba.github.io/form-render/docs/demo/index.html)
[快速开始](README)
