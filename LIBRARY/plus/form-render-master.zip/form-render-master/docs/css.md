# 样式覆盖

### 概述
- FormRender 其实是有一个默认的布局样式，比如说表单之间的间距，label 字号、颜色等场景
- 假如使用上有特殊定制，或者认为不符合要求的地方，可以通过常规 CSS 样式覆盖的方式，写到业务 global 样式代码中

### 如何使用

![](https://img.alicdn.com/tfs/TB1NEHdKpzqK1RjSZFoXXbfcXXa-2782-1488.png)

